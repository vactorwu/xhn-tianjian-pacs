#include <windows.h>
#include <stdlib.h>
#include <stdio.h>

// Declare function protypes exported by NHSETUP.DLL
#ifdef __cpluscplus
extern "C" {
#endif
extern ULONG PASCAL GetDLLVersion(void);
extern ULONG PASCAL GetInstallInfo(void);
extern ULONG PASCAL Install(const char * srcpath);
extern ULONG PASCAL Remove(ULONG * pSerialNo);
#ifdef __cplusplus
}
#endif

int main(int argc, char *argv[])
{
	ULONG ver, ret, RetCode;
	static ULONG SerialNo;
	char c;
	DWORD wret;


	ver = GetDLLVersion();

	printf("Setup for GS-NH. ");
	printf("Version: %d.%03d\n", ver>>16, ver&0xffff);
	printf("Copyright Rainbow Goldensoft Co. Ltd. 2000\n\n");

	if(argc<2)
	{
		printf("Usage: Setup install\n");
		printf("       Setup remove [serial number of the dog you want to remove]\n");
		printf("               The serial number parameter is optional.\n");
		printf("       Setup info\n");
		return 2;
	}

	if( !lstrcmpi(argv[1], "remove") )
	{
		if(argc == 2)
		{
			printf("\nYou will stop and delete all the Dog service. Are you sure?(Y/N)");
			while(((c = getchar()) == EOF)||((toupper(c) != 'Y')&&(toupper(c) != 'N')));
			if(toupper(c) == 'Y')
			{
				SerialNo = 0;
			}
			else
			{
				printf("\nPlease input the serial number of the dog you want to remove:\t");
				if(!scanf("%u", &SerialNo))
				{
					printf("\nThe serial number you input is wrong.");
					return 3;
				}
			}
		}
		else if(argc == 3)
		{
			SerialNo = strtoul(argv[2], NULL, 10);
			printf("The serial number you want to remove is %u\n",SerialNo);
		}
		else
		{
			printf("\nThe parameter you input is wrong.");
			return 4;
		}

		ret = Remove((ULONG *)&SerialNo);

		if((ret == 0)&&(SerialNo == 0))
			printf("Drivers have been removed successfully. \n");
		else if((ret == 0)&&(SerialNo != 0))
			printf("The %u Dog has been removed successfully.\n",SerialNo);
		else
			printf("Error occurs when remove DogServer, error code=%u\n", ret);
	}

	else if( !lstrcmpi(argv[1],"info") )
	{
		ret = GetInstallInfo();

		if(ret == 0)
			printf("Dog Server is running well.\n");
		else
			printf("Dog Server running status: %ld\n", ret);

	}

	else if( !lstrcmpi(argv[1],"install") )
	{
		ret = Install("."); // Current directory

		if(ret == 0)
			printf("Dog Server have been installed successfully.\n");
		else
			printf("Error occurs when install Dog Server, error code = %ld\n", ret);
	}

	else
	{
		printf("Usage: Setup install\n");
		printf("       Setup remove [serial number of the dog you want to remove]\n");
		printf("               The serial number parameter is optional.\n");
		printf("       Setup info\n");
		return 5;
	}

	return 0;
}
