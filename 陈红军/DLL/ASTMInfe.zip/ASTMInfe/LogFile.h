
bool NewLogFile(LPSTR  filename);
void WriteLogData(HANDLE hFile,LPSTR Buffer,int size);
void CloseLogFile(HANDLE hFile);