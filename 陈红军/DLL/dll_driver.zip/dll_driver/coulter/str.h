double StrToFloat(const char * lpStr, int nMaxLength);
int HStrToInt(const char * lpStr, int nMaxLength);
int StrToInt(const char * lpStr, int nMaxLength);